def calculate_scores(product):
    return {
        "satisfaction": {"score": 85, "comment": "Genel memnuniyet yüksek."},
        "flaw": {"score": 20, "comment": "Bazı kullanıcılar kargo süresinden şikayet etmiş."},
        "aura": {"score": 78, "comment": "Ürün şık ve kaliteli algısı veriyor."},
        "expert": {"score": 82, "comment": "Bağımsız testlerde başarılı sonuçlar almış."}
    }
