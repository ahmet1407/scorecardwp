def scrape_amazon_product(url):
    return {
        "name": "Duracell DL2032 3V Lithium Pil",
        "price": "139 TL",
        "description": "Dayanıklı, uzun ömürlü düğme pil",
        "reviews": []
    }
