def scrape_hepsiburada_product(url):
    return {
        "name": "Madame Coco Saklama Kabı",
        "price": "179 TL",
        "description": "500ml ahşap kapaklı 2'li set",
        "reviews": []
    }
