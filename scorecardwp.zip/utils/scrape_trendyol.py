def scrape_trendyol_product(url):
    return {
        "name": "Arzum Okka Türk Kahvesi Makinesi",
        "price": "2.499 TL",
        "description": "Köpüklü kahve deneyimi",
        "reviews": []
    }
